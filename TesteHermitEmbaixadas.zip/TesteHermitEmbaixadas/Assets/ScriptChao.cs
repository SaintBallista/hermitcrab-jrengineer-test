﻿using UnityEngine;
using System.Collections;

public class ScriptChao : MonoBehaviour {
    public GameObject bola;

    bool bolacaiu=false;

	void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == bola)
        {
            bolacaiu = true;
        }
    }

    public bool getBolaCaiu()
    {
        return bolacaiu;
    }
}
