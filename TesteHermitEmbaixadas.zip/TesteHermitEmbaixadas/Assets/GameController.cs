﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    public Text numero_score;
    public GameObject perna_esq;
    public GameObject perna_dir;
    public GameObject volume_dir_obj;
    public GameObject volume_esq_obj;
    public GameObject bola;
    public AudioSource gameover_audio;
    public AudioSource normal_audio;
    public GameObject chao;
    public GameObject texto_gameover;

    ScriptChao scriptchao;
    VolumeScript volume_dir;
    VolumeScript volume_esq;

    float timer_fim=0f;
    float tempo_ultimo_chute = 0f;
    bool pode_chutar = true;
    int score = 0;
    Vector2 mouse;
    Vector3 velocity;
    public bool gameover=false;


	// Use this for initialization
	void Start () {
        numero_score = numero_score.GetComponent<Text>();

        volume_dir = volume_dir_obj.GetComponent<VolumeScript>();
        volume_esq = volume_esq_obj.GetComponent<VolumeScript>();

        scriptchao = chao.GetComponent<ScriptChao>();
        normal_audio.Play();
        numero_score.text = score.ToString();
	}

    void Update()
    {


        gameover = scriptchao.getBolaCaiu();
        if (Input.GetMouseButtonDown(0) && (pode_chutar ==true) &&(gameover==false))
        {
            mouse = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
            if (mouse.x < Screen.width / 2) //player clicou no lado esqurdo da tela
            {
                perna_esq.SetActive(true);
                

                if (volume_esq.getBolaAqui() == true)
                {
                    score = score+1;
                    ChutaBola();
                }

                
            }

            if (mouse.x > Screen.width / 2) // player clicou no lado direito da tela
            {
                perna_dir.SetActive(true);
                

                if (volume_dir.getBolaAqui() == true)
                {
                    score = score + 1;
                    ChutaBola();
                }
            }
            pode_chutar = false;
            numero_score.text = score.ToString();
        }

        if (pode_chutar == false)
        {
            tempo_ultimo_chute += Time.deltaTime;
        }
        if (tempo_ultimo_chute > 1f)
        {
            perna_dir.SetActive(false);
            perna_esq.SetActive(false);
            tempo_ultimo_chute = 0f;
            pode_chutar = true;
        }


        
        if (gameover == true)
        {
            ChamaGameOver();
        }

        if (gameover == true)
        {
            timer_fim += Time.deltaTime;
        }
        if(timer_fim > 3f)
        {
            SceneManager.LoadScene("menu_principal");
        }


    }
	
    void ChutaBola()
    {
        int fator = Random.Range(0, 2);
        switch (fator) {

            case 0:
                velocity = new Vector3(100, 100, 0);
                break;
            case 1:
                velocity = new Vector3(-100, 100, 0);
                break;

        }
        
        bola.GetComponent<Rigidbody>().velocity = velocity;
    }


    void ChamaGameOver()
    {
        normal_audio.Pause();
        gameover_audio.Play();
        texto_gameover.SetActive(true);
    }

	
}
