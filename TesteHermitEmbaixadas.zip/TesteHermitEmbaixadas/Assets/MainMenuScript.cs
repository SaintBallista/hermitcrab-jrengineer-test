﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour {

    public Button jogarTexto;
    public Button sairTexto;


    void Start()
    {

        jogarTexto = jogarTexto.GetComponent<Button>();
        sairTexto = sairTexto.GetComponent<Button>();
    }


    public void Jogar()
    {
        SceneManager.LoadScene("jogo_embaixadas");
    }

    
    public void SairDoJogo()
    {
        Application.Quit();
    }
}
