﻿using UnityEngine;
using System.Collections;

public class ScriptBarreira : MonoBehaviour {

    public GameObject bola;
    public bool horizontal;

    Vector3 direcao;

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == bola)
        {
            if (horizontal == false)
            {
                direcao = new Vector3(bola.GetComponent<Rigidbody>().velocity[0], -bola.GetComponent<Rigidbody>().velocity[1], -bola.GetComponent<Rigidbody>().velocity[2]);
            }
            else
            {
                direcao = new Vector3(-bola.GetComponent<Rigidbody>().velocity[0], bola.GetComponent<Rigidbody>().velocity[1], -bola.GetComponent<Rigidbody>().velocity[2]);
            }
            bola.GetComponent<Rigidbody>().velocity = direcao/2;
            
        }
    }
}
