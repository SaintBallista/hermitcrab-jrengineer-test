﻿using UnityEngine;
using System.Collections;

public class VolumeScript : MonoBehaviour
{


    public GameObject bola;

    bool bola_aqui = true;


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == bola)
        {
            bola_aqui = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject == bola)
        {
            bola_aqui = false;
        }
    }

    public bool getBolaAqui()
    {
        return bola_aqui;
    }

}
